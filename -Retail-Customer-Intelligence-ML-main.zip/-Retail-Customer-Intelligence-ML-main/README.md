# 📊 Customer Behavioral Analytics & Predictive Modeling

This project transforms raw retail transaction data into actionable business intelligence. By leveraging **RFM (Recency, Frequency, Monetary) Analysis**, **K-Means Clustering**, and **Random Forest Machine Learning**, the system segments customers and predicts their future spending and churn probability.

---

## 📂 Dataset Source
The data used in this project is the **Online Retail Dataset** provided by the UCI Machine Learning Repository. It contains transactions occurring between 01/12/2010 and 09/12/2011 for a UK-based, non-store online retail business.

*   **Dataset Link:** [UCI Online Retail Dataset](https://archive.ics.uci.edu/dataset/352/online+retail)
*   **How to use:** 
    1. Download the dataset from the link above.
    2. Convert or save the file as `retail.csv`.
    3. Place the file in the root directory of this project before running the script.

---

## 🚀 Project Performance

- **Churn Prediction Accuracy:** 83.99% (Random Forest Classifier)  
- **Revenue Prediction (R²):** 0.66 (Tag-based model)  
- **Revenue Prediction (R²):** 0.53 (Raw metrics model)  
- **Clustering Quality:** 0.31 Silhouette Score  

---

## 📈 Customer Segments (K-Means Results)

Based on cluster means, the customer base is divided into four strategic groups:

### 🟢 Champions
- Recency: 12.5 Days  
- Frequency: 226 Orders  
- Monetary: $4,592.60  
- Description: High-value, highly frequent, and very recent customers  

### 🔵 Loyal Customers
- Recency: 89.9 Days  
- Frequency: 80 Orders  
- Monetary: $1,413.11  
- Description: Consistent and steady spenders  

### 🟡 New / Recent Shoppers
- Recency: 24.9 Days  
- Frequency: 30 Orders  
- Monetary: $470.45  
- Description: Recent customers with growth potential  

### 🔴 Hibernating / Lost
- Recency: 200.6 Days  
- Frequency: 15 Orders  
- Monetary: $303.84  
- Description: Inactive customers with high churn risk  

---


## 🛠️ Technical Methodology

### 1. Data Engineering & Cleaning
- Removed null `CustomerID` values  
- Filtered negative quantities and prices  
- Capped RFM metrics at the 99th percentile to handle outliers  
- Applied `log1p` transformation to reduce skew  

> Result: Improved Revenue R² from **0.28 → 0.66**

---

### 2. Machine Learning Pipeline

**Unsupervised Learning**
- K-Means clustering on scaled + log-transformed RFM data  

**Supervised Learning (Regression)**
- Random Forest Regressor to predict customer monetary value  

**Supervised Learning (Classification)**
- Random Forest Classifier to predict churn  
- Churn defined as: `Recency > 90 days`

---

## 📋 Business Insights

- **Frequency drives revenue:** ~3× more predictive than recency  
- **Champions dominate value:** Major contributors to revenue forecasting  
- **High-confidence churn prediction:** Enables automated retention strategies  
- **Actionable targeting:** Ideal for win-back campaigns on inactive users  

---

## ⚙️ Setup and Installation

### 1. Clone the repository
```bash
git https://github.com/Amit-Krishna/-Retail-Customer-Intelligence-ML
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```


---

## 📧 Contact

**Amit Krishna**  
[LinkedIn Profile](https://www.linkedin.com/in/amit-krishna/)  
[Portfolio / Website](https://amit-krishna.github.io/Portfolio/)
